public class Anwendungsbeispiel {
   public static void main(String[] args) {
      Zahlungsmittel geld[]= {new USD_Muenze(0.10), new USD_Schein(20),   new SFR_Schein(5),
                              new SFR_Muenze(0.50), new USD_Muenze(0.50), new EUR_Schein(50),
                              new USD_Schein(100),  new USD_Muenze(0.2),  new USD_Muenze(0.25),
                              new EUR_Muenze(0.01), new SFR_Schein(200),  new USD_Schein(100),
                              new EUR_Muenze(2),    new EUR_Schein(5),    new USD_Muenze(0.25),
                              new SFR_Muenze(0.10), new SFR_Muenze(0.01), new USD_Muenze(0.50),
                              new USD_Schein(100),  new USD_Schein(100),  new USD_Muenze(0.2),
                              new USD_Muenze(0.01), new SFR_Schein(20),   new SFR_Muenze(0.50),
                              new USD_Muenze(0.50), new EUR_Schein(50),   new USD_Schein(5),
		              new EUR_Muenze(0.50), new EUR_Muenze(0.01), new SFR_Schein(10),
		              new SFR_Schein(20),   new SFR_Muenze(0.50), new SFR_Muenze(0.02)};
  }
}
